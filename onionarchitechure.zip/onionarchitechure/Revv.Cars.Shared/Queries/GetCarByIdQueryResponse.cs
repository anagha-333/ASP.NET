﻿using Revv.Cars.Shared;

namespace Revv.Cars.Shared.Queries
{

    public class GetCarByIdQueryResponse
    {
        public Car? Car { get; set; }
    }
}
