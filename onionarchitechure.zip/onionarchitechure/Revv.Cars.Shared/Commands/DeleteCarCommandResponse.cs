﻿namespace Revv.Cars.Shared.Commands
{
    public class DeleteCarCommandResponse
    {

    }
}
