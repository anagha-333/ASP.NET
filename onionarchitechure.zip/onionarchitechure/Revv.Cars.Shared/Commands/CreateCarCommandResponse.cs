﻿using Revv.Cars.Shared;

namespace Revv.Cars.Shared.Commands
{
    public class CreateCarCommandResponse
    {
        public Car Car { get; set; } = default!;
    }
}
