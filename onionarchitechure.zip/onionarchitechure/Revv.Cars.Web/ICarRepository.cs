﻿internal interface ICarRepository
{
}